import requests
import zipfile
import os

LOCAL_VERSION_FILE = "version.txt"
ONLINE_VERSION_URL = "https://raw.githubusercontent.com/AshikAtwic/patch-updater/refs/heads/main/version.txt"
UPDATE_ZIP_URL = "https://github.com/AshikAtwic/patch-updater/raw/main/update_v1.1.zip"  # Replace with your actual file name
UPDATE_ZIP_NAME = "update.zip"
UPDATE_DIR = "./"  # Or set to "Files/" if updates are inside a folder


def get_current_version():
    try:
        with open(LOCAL_VERSION_FILE, "r") as f:
            return f.read().strip()
    except FileNotFoundError:
        return "0.0"

def get_latest_version():
    r = requests.get(ONLINE_VERSION_URL)
    return r.text.strip()

def download_update():
    r = requests.get(UPDATE_ZIP_URL)
    with open(UPDATE_ZIP_NAME, 'wb') as f:
        f.write(r.content)

def apply_update():
    with zipfile.ZipFile(UPDATE_ZIP_NAME, 'r') as zip_ref:
        zip_ref.extractall(UPDATE_DIR)
    os.remove(UPDATE_ZIP_NAME)
