from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QLabel, QVBoxLayout, QWidget
import updater

class MainApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Patch Update Example")
        layout = QVBoxLayout()

        self.version_label = QLabel(f"Current Version: {updater.get_current_version()}")
        self.check_button = QPushButton("Check for Updates")
        print("newzip uploded file")
        self.check_button.clicked.connect(self.check_for_updates)

        layout.addWidget(self.version_label)
        layout.addWidget(self.check_button)

        central = QWidget()
        central.setLayout(layout)
        self.setCentralWidget(central)

    def check_for_updates(self):
        latest = updater.get_latest_version()
        current = updater.get_current_version()
        if latest > current:
            updater.download_update()
            updater.apply_update()
            self.version_label.setText(f"Updated to version {latest}")
            with open("version.txt", "w") as f:
                f.write(latest)
        else:
            self.version_label.setText("You're up to date!")

if __name__ == "__main__":
    app = QApplication([])
    window = MainApp()
    window.show()
    app.exec_()
